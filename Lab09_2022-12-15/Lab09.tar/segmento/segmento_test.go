package main

import (
	"fmt"
	"testing"
)

var prog = "./rettangolo"

func TestEsistenzaMetodo(t *testing.T) {
	var s Segmento
	//fmt.Println(r)
	fmt.Println(s.String())
}
